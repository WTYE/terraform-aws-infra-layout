# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
#
# This AWS Content is provided subject to the terms of the AWS Customer Agreement
# available at http://aws.amazon.com/agreement or other written agreement between
# Customer and either Amazon Web Services, Inc. or Amazon Web Services EMEA SARL or both.
set -e
source ${BASH_SOURCE%/*}/ssm.sh

function kms_get_key_by_alias_directly() {
    local -r prefix=$1
    local -r key_alias=$2
    local -r region=$3
    echo $(aws kms describe-key --key-id "alias/$prefix/$key_alias" --region $region | jq -r .KeyMetadata.Arn)
}

function kms_get_key_by_alias() {
    local -r key_alias=$1

    if [ -z $key_alias ]; then
        echo "[ERROR] Missing key alias"
        exit 1
    fi

    local -r prefix=$(get_prefix)
    assume_role $(accounts_get security)
    echo $(kms_get_key_by_alias_directly $prefix $key_alias $(get_main_region))
}

function kms_get_terraform_key() {
    echo $(kms_get_key_by_alias $TERRAFORM)
}

function kms_get_begin_key() {
    is_cn && echo $(kms_get_key_by_alias_directly cf-beginning begin $BEIJING) || echo $(kms_get_key_by_alias_directly cf-beginning begin $TOKYO)
}
