# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
#
# This AWS Content is provided subject to the terms of the AWS Customer Agreement
# available at http://aws.amazon.com/agreement or other written agreement between
# Customer and either Amazon Web Services, Inc. or Amazon Web Services EMEA SARL or both.
set -e
source ${BASH_SOURCE%/*}/kms.sh

function get_bucket() {
    local -r bucket=$1

    local -r bucket_prefix="$(get_prefix)-bucket"
    local -r logs_prefix="$bucket_prefix-logs"

    case $bucket in
    $INITIAL) echo "$logs_prefix-$INITIAL-$(accounts_get logs)" ;;
    $TERRAFORM) echo "$logs_prefix-$TERRAFORM-$(accounts_get logs)" ;;
    "ui") echo "$bucket_prefix-ui-$(accounts_get logs)" ;;
    *)
        echo "[ERROR] Unsupported bucket [$bucket]"
        exit 1
        ;;
    esac
}

function terraform_check() {
    if [ -z $AWS_DEFAULT_REGION ]; then
        echo "[ERROR] Missing AWS_DEFAULT_REGION"
        exit 1
    fi
}

function terraform_init_local() {
    terraform -chdir="." init \
        -reconfigure \
        -input=false \
        -plugin-dir=$TERRAFORM_DIR
}

function terraform_init_s3() {
    local -r location=$1
    local -r dir=$2
    local -r state=$3
    local -r account=$4

    if [ -z $account ]; then
        echo "[INFO] Missing account"
        exit 1
    fi

    local -r bucket_key="key=state/${account}/$(get_region)/${state}.tfstate"
    local role_arn
    local kms_key_arn

    echo "Initialize terraform from [$location] with key [$bucket_key]"
    case $location in
    $BEGIN)
        bucket="bucket=$TF_VAR_begin_bucket"
        kms_key_arn="kms_key_id=$(kms_get_begin_key)"
        is_cn && bucket_region="region=$BEIJING" || bucket_region="region=$TOKYO"

        echo "  at $bucket"
        terraform -chdir=$dir init \
            -no-color \
            -reconfigure \
            -input=false \
            -backend-config=$bucket \
            -backend-config=$bucket_key \
            -backend-config=$kms_key_arn \
            -backend-config=$bucket_region \
            -plugin-dir=$TERRAFORM_DIR
        ;;
    $BOOTSTRAP)
        bucket="bucket=$TF_VAR_bootstrap_bucket"
        kms_key_arn="kms_key_id=$(kms_get_key_by_alias_directly $TF_VAR_prefix bootstrap $(get_main_region))"

        echo "  at $bucket"
        terraform -chdir=$dir init \
            -no-color \
            -reconfigure \
            -input=false \
            -backend-config=$bucket \
            -backend-config=$bucket_key \
            -backend-config=$kms_key_arn \
            -plugin-dir=$TERRAFORM_DIR
        ;;
    $INITIAL)
        # the initial key allows infra account to use
        bucket="bucket=$(get_bucket $INITIAL)"
        kms_key_arn="kms_key_id=$(kms_get_key_by_alias initial)"
        role_arn="role_arn=arn:$(get_partition):iam::$(accounts_get infra):role/$CF_MANAGER_ROLE"

        echo "  at $bucket"
        terraform -chdir=$dir init \
            -no-color \
            -reconfigure \
            -input=false \
            -backend-config=$bucket \
            -backend-config=$bucket_key \
            -backend-config=$kms_key_arn \
            -backend-config=$role_arn \
            -plugin-dir=$TERRAFORM_DIR
        ;;
    $SETUP)
        bucket="bucket=$(get_bucket $TERRAFORM)"
        kms_key_arn="kms_key_id=$(kms_get_terraform_key)"
        role_arn="role_arn=arn:$(get_partition):iam::$(accounts_get logs):role/$CF_MANAGER_ROLE"

        echo "  at $bucket"
        terraform -chdir=$dir init \
            -no-color \
            -reconfigure \
            -input=false \
            -backend-config=$bucket \
            -backend-config=$bucket_key \
            -backend-config=$kms_key_arn \
            -backend-config=$role_arn \
            -plugin-dir=$TERRAFORM_DIR
        ;;
    *)
        echo "[ERROR] Unsupported location [$location]."
        exit 1
        ;;
    esac
}

function terraform_plan() {
    local -r dir=$1
    local -r action=$2

    [ -d $TFPLAN_DIR ] && rm -rf $TFPLAN_DIR
    mkdir -p $TFPLAN_DIR

    [ -d $LAMBDA_DIR ] && rm -rf $LAMBDA_DIR
    mkdir -p $LAMBDA_DIR
    # there are modules without lambda zip files
    touch $LAMBDA_DIR/touch

    terraform -chdir=$dir validate -no-color

    case $action in
    "apply" | "apply_fresh") terraform -chdir=$dir plan -no-color -input=false -out=$TFPLAN >$TFPLAN_TXT ;;
    "destroy") terraform -chdir=$dir plan -no-color -input=false -out=$TFPLAN -destroy >$TFPLAN_TXT ;;
    *)
        echo "[ERROR] unknown action: $action"
        exit 1
        ;;
    esac

    cat $TFPLAN_TXT
}

function terraform_apply() {
    local -r dir=$1
    local -r action=$2

    terraform -chdir=$dir validate -no-color

    case $action in
    "apply") terraform -chdir=$dir apply -no-color -input=false $TFPLAN ;;
    "apply_fresh") terraform -chdir=$dir apply -no-color -input=false -auto-approve ;;
    "destroy") terraform -chdir=$dir apply -no-color -input=false -destroy -auto-approve ;;
    *)
        echo "[ERROR] unknown action: $action"
        exit 1
        ;;
    esac
}

function terraform_do() {
    local -r dir=$1
    local -r action=$2
    local -r account=$3
    local -r state=$4
    local -r location=$5
    local -r init=$6

    if [ -z $dir ]; then
        echo "[ERROR] Missing directory"
        exit 1
    fi

    if [ -z $action ]; then
        echo "[ERROR] Missing action"
        exit 1
    fi

    if [ -z $account ] || [ ${#account} != 12 ]; then
        echo "[ERROR] Missing account"
        exit 1
    fi

    if [ -z $state ]; then
        echo "[ERROR] Missing state"
        exit 1
    fi

    terraform_check

    echo "[$action] [$state] to [$account] at [$location] ($init)"
    if [ ! -z $init ] && [ $init == "init" ]; then
        terraform_init_s3 $location $dir $state $account
    fi

    terraform_plan $dir $action
    terraform_apply $dir $action
}
