# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
#
# This AWS Content is provided subject to the terms of the AWS Customer Agreement
# available at http://aws.amazon.com/agreement or other written agreement between
# Customer and either Amazon Web Services, Inc. or Amazon Web Services EMEA SARL or both.

# This file must not source any other files.

declare -rA PROVIDERS=(
    [aws]="5.7.0"
    [archive]="2.3.0"
)

declare -rA MODULES=(
    [s3-bucket]="3.14.0"
    [vpc]="5.0.0"
)

readonly BEIJING="cn-north-1"
readonly TOKYO="ap-northeast-1"

readonly TERRAFORM_VERSION="1.5.2"
readonly BEGIN="begin"
readonly BOOTSTRAP="bootstrap"
readonly INITIAL="initial"
readonly SETUP="setup"

readonly CF_MANAGER_ROLE="cf-manager-role"
readonly ORG_ROLE="OrganizationAccountAccessRole"

readonly URL_HASHICORP="https://releases.hashicorp.com"
readonly URL_GITHUB="https://github.com/terraform-aws-modules"
readonly URL_CUSTODIAN="https://cloudcustodian.io/downloads/custodian-cask/linux-latest"

readonly OPT_DIR="/opt"
readonly TERRAFORM="terraform"
readonly TERRAFORM_DIR="$OPT_DIR/$TERRAFORM"
readonly HASHICORP_DIR="$TERRAFORM_DIR/registry.terraform.io/hashicorp"
readonly MODULES_DIR="$TERRAFORM_DIR/terraform-aws-modules"
readonly LANDING_ZONE_ZIP="landing_zone.zip"

readonly LAMBDA_DIR="$TERRAFORM_DIR/lambda"
readonly TFPLAN_DIR="$TERRAFORM_DIR/build"
readonly TFPLAN="$TFPLAN_DIR/tfplan"
readonly TFPLAN_TXT="$TFPLAN.txt"
