# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
#
# This AWS Content is provided subject to the terms of the AWS Customer Agreement
# available at http://aws.amazon.com/agreement or other written agreement between
# Customer and either Amazon Web Services, Inc. or Amazon Web Services EMEA SARL or both.
set -e

function retry() {
    local -r cmd="$1"

    for ((i = 0; i < 10; i++)); do
        if ! $($cmd); then
            echo "retry [$i] times for [$cmd]"
            sleep 1
        else
            return $(true) # without $(true) the program stops
        fi
    done

    echo "[ERROR] failed to [$cmd]"
    exit 1
}

function is_cn() {
    [[ $(get_region) == "cn-"* ]] && return $(true) || return $(false)
}

function get_os() {
    echo $(uname -s)
}

function get_uuid() {
    case $(get_os) in
    "Linux") echo $(uuidgen) ;;
    "Darwin") echo $(uuidgen) ;;
    *)
        echo "[ERROR] Unsupported OS."
        exit 1
        ;;
    esac
}

function get_arch() {
    case $(uname -m) in
    "x86_64") echo "amd64" ;;
    "arm64") echo "arm64" ;;
    *)
        echo "[ERROR] Unsupported architecture."
        exit 1
        ;;
    esac
}

function get_cn_suffix() {
    is_cn && echo ".cn" || echo ""
}

function get_partition() { # the * should be outside of the quote
    is_cn && echo "aws-cn" || echo "aws"
}

# Get the current deploying region.
# If deploying to only one region, setting AWS_DEFAULT_REGION is enough.
# if deploying to multiple regions, you need to set both variables:
#   - TF_VAR_region is the target region;
#   - AWS_DEFAULT_REGION is the main region;
# must use double [[ ]] for -n
function get_region() {
    if [[ -n $TF_VAR_region ]]; then
        echo $TF_VAR_region
    elif [[ -n $AWS_DEFAULT_REGION ]]; then
        echo $AWS_DEFAULT_REGION
    else
        echo "[ERROR] Missing deploying region"
        exit 101
    fi
}

# Get the main region, which is always set by AWS_DEFAULT_REGION
function get_main_region() {
    if [[ -n $AWS_DEFAULT_REGION ]]; then
        echo $AWS_DEFAULT_REGION
    else
        echo "[ERROR] Missing main region"
        exit 101
    fi
}

function get_terraform_file() {
    local -r version=$1
    local -r os=$2
    local -r arch=$3

    echo "${TERRAFORM}_${version}_${os}_${arch}.zip"
}

function get_terraform_url() {
    local -r version=$1
    local -r os=$2
    local -r arch=$3

    echo "$URL_HASHICORP/terraform/$version/$(get_terraform_file $version $os $arch)"
}

function get_provider_file() {
    local -r name=$1
    local -r version=$2
    local -r os=$3
    local -r arch=$4

    echo "$TERRAFORM-provider-${name}_${version}_${os}_${arch}.zip"
}

function get_provider_url() {
    local -r name=$1
    local -r version=$2
    local -r os=$3
    local -r arch=$4

    echo "$URL_HASHICORP/terraform-provider-$name/$version/$(get_provider_file $name $version $os $arch)"
}

function get_module_file() {
    local -r name=$1
    local -r version=$2

    echo "$TERRAFORM-aws-${name}-${version}.zip"
}

function get_module_url() {
    local -r name=$1
    local -r version=$2

    echo "$URL_GITHUB/terraform-aws-$name/archive/refs/tags/v$version.zip"
}

function zip_src() {
    local -r is_begin=$1
    local wild="*"

    if [[ $is_begin == "true" ]]; then
        wild="terraform.tfstate*"
    fi

    cd ${BASH_SOURCE%/*}/../../

    mkdir -p $TERRAFORM_DIR
    [ -f $TERRAFORM_DIR/$LANDING_ZONE_ZIP ] && rm -f $TERRAFORM_DIR/$LANDING_ZONE_ZIP

    zip -qr $TERRAFORM_DIR/$LANDING_ZONE_ZIP . \
        --exclude=".*" \
        --exclude="*.md" \
        --exclude="*/.*" \
        --exclude="*/tfplan" \
        --exclude="*/tfplan.txt" \
        --exclude="*/*.tfstate" \
        --exclude="*/*.tfstate.backup" \
        --exclude="*/package-lock.json" \
        --exclude="*/node_modules/*" \
        --exclude="bash/bootstrap/$wild" \
        --exclude="bash/bootstrap/codebuild/terraform/*" \
        --exclude="document/*" \
        --exclude="terraform/beginning/$wild" \
        --exclude="ui/build/*"
}
