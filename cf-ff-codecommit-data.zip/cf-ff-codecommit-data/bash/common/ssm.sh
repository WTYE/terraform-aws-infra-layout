# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
#
# This AWS Content is provided subject to the terms of the AWS Customer Agreement
# available at http://aws.amazon.com/agreement or other written agreement between
# Customer and either Amazon Web Services, Inc. or Amazon Web Services EMEA SARL or both.
set -e
source ${BASH_SOURCE%/*}/iam.sh

function get_prefix() {
    assume_role $(accounts_get infra)
    echo $(aws ssm get-parameter --name "/cf/prefix" --region $(get_main_region) | jq -r .Parameter.Value)
}

function get_parameter() {
    local -r name=$1
    local -r prefix=$(get_prefix)
    assume_role $(accounts_get infra)
    echo $(aws ssm get-parameter --name "/$prefix/parameter$name" --with-decryption --region $(get_main_region) | jq -r .Parameter.Value)
}

function put_parameter() {
    local -r name=$1
    local -r value=$2
    local -r prefix=$(get_prefix)
    local -r key_id=$(kms_get_terraform_key)
    assume_role $(accounts_get infra)
    aws ssm put-parameter --name "/$prefix/parameter$name" --value "$value" --type SecureString --key-id $key_id --overwrite --region $(get_main_region)
}
