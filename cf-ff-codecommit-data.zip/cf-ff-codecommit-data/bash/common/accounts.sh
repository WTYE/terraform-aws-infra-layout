# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
#
# This AWS Content is provided subject to the terms of the AWS Customer Agreement
# available at http://aws.amazon.com/agreement or other written agreement between
# Customer and either Amazon Web Services, Inc. or Amazon Web Services EMEA SARL or both.
set -e

# This file must not source any other files.
# The four core accounts
function accounts_get() {
    local -r name=$1

    if [ -z $name ]; then
        echo "[ERROR] Missing account name"
        exit 1
    fi

    # quote it as it is a json string.
    if [ -z "$TF_VAR_accounts" ]; then
        echo "[ERROR] Missing TF_VAR_accounts"
        exit 1
    fi

    echo $TF_VAR_accounts | jq -r .$name
}

function accounts_is_core() {
    local -r account=$1
    local -ra core=(
        $(accounts_get management)
        $(accounts_get infra)
        $(accounts_get logs)
        $(accounts_get security)
    )

    for i in "${core[@]}"; do
        [[ $i == $account ]] && return $(true)
    done
    return $(false)
}

function accounts_get_region_status() {
    local -r org_enabled=$1
    local -r region=$2
    local -r account=$3

    if [[ $org_enabled == "true" ]] && [[ $(accounts_get management) != $account ]]; then
        echo $(aws account get-region-opt-status --account-id $account --region-name $region --query "RegionOptStatus" --output text)
    else
        echo $(aws account get-region-opt-status --region-name $region --query "RegionOptStatus" --output text)
    fi
}

function accounts_enable_region() {
    local -r org_enabled=$1
    local -r region=$2
    local -r account=$3

    if [[ $org_enabled == "true" ]] && [[ $(accounts_get management) != $account ]]; then
        iam_sts_set_version
        aws account enable-region --account-id $account --region-name $region
    else
        if [[ $(accounts_get management) != $account ]]; then
            assume_role_directly_as $account $ORG_ROLE
        fi
        iam_sts_set_version
        aws account enable-region --region-name $region
    fi
}
