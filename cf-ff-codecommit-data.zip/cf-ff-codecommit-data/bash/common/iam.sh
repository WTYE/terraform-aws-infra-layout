# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
#
# This AWS Content is provided subject to the terms of the AWS Customer Agreement
# available at http://aws.amazon.com/agreement or other written agreement between
# Customer and either Amazon Web Services, Inc. or Amazon Web Services EMEA SARL or both.
set -e
source ${BASH_SOURCE%/*}/accounts.sh
source ${BASH_SOURCE%/*}/base.sh
source ${BASH_SOURCE%/*}/constants.sh

function assume_role_directly_as() {
  local -r target_account=$1
  local -r role_name=$2
  local -r external_id=$3

  if [ -z $target_account ]; then
    echo "[ERROR] Missing target_account"
    exit 1
  fi

  local -r role_path="/tmp/$EXEC_ID/cf/role"
  mkdir -p $role_path
  local -r tmp_role="$role_path/tmp_file" # prefer to use exec_id instead of uuid here
  local -r role_arn="arn:$(get_partition):iam::${target_account}:role/${role_name}"
  if [ -z $external_id ]; then
    aws sts assume-role \
      --role-arn $role_arn \
      --role-session-name "cloud-foundations" \
      --duration-seconds 1800 >$tmp_role
  else
    aws sts assume-role \
      --role-arn $role_arn \
      --role-session-name "cloud-foundations" \
      --duration-seconds 1800 \
      --external-id $external_id >$tmp_role
  fi
  if [ $? != 0 ]; then return 101; fi # return 101 here to make sure it's failed properly

  export AWS_ACCESS_KEY_ID=$(cat $tmp_role | jq -r '.Credentials.AccessKeyId')
  export AWS_SECRET_ACCESS_KEY=$(cat $tmp_role | jq -r '.Credentials.SecretAccessKey')
  export AWS_SESSION_TOKEN=$(cat $tmp_role | jq -r '.Credentials.SessionToken')

  # env var exported here cannot be captured by parent process, thus use a shared file.
  # [ -f $tmp_role ] && rm $tmp_role
}

function assume_role_directly() {
  local -r target_account=$1

  assume_role_directly_as $target_account $CF_MANAGER_ROLE
}

# do not echo in this function
function assume_management_role() {
  assume_role_directly $(accounts_get management)
}

function assume_role() {
  local -r target_account=$1

  if [ -z $target_account ]; then
    echo "[ERROR] Missing target_account"
    exit 1
  fi

  assume_management_role

  if [ $target_account == $(accounts_get management) ]; then
    return
  fi

  assume_role_directly $target_account
}

function org_get_accounts() {
  echo $(aws organizations list-accounts --query "Accounts[?Status=='ACTIVE'].Id" --output text --no-paginate)
}

function iam_set_sts_version() {
    local -r account=$1

    if [[ $(accounts_get management) != $account ]]; then
        assume_role_directly_as $account $ORG_ROLE
    fi

    aws iam set-security-token-service-preferences --global-endpoint-token-version v2Token
}
