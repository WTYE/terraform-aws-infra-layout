# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
#
# This AWS Content is provided subject to the terms of the AWS Customer Agreement
# available at http://aws.amazon.com/agreement or other written agreement between
# Customer and either Amazon Web Services, Inc. or Amazon Web Services EMEA SARL or both.
set -e
source ${BASH_SOURCE%/*}/base.sh

function s3_get_object() {
  local -r bucket=$1
  local -r key=$2
  local -r file=$3
  local -r dir=$4
  local -r unzip=$5

  echo "Download S3 file [$bucket/$key] to [/tmp/$file] and move to [$dir]"
  aws s3api get-object \
    --region $(get_main_region) \
    --bucket $bucket \
    --key $key \
    /tmp/$file >/dev/null

  mkdir -p $dir
  if [ ! -z $unzip ] && [ $unzip == "true" ]; then
    echo "Unzip [$file] to [$dir]"
    unzip -qo /tmp/$file -d $dir
  else
    echo "Move [$file] to [$dir]"
    mv -f /tmp/$file $dir
  fi
}

function s3_put_object() {
  local -r bucket=$1
  local -r key=$2
  local -r file=$3
  local -r kms_arn=$4
  local -r type=$5

  if [ ! -f $file ]; then
    echo "Unable to find file [$file]"
    exit 1
  fi

  local content_type=$type
  if [ -z $type ]; then
    content_type="application/octet-stream"
  fi

  echo "Upload [$file] to S3 location [$bucket/$key]"
  aws s3api put-object \
      --body $file \
      --bucket $bucket \
      --key $key \
      --content-type $content_type \
      --server-side-encryption aws:kms \
      --ssekms-key-id $kms_arn >/dev/null
}
